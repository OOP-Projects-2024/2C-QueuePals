<?php

require_once "./config/database.php";
require_once "./functions/Get.php";
require_once "./functions/Post.php";
require_once "./functions/Patch.php";
require_once "./functions/Delete.php";
require_once "./functions/Auth.php";


$pdo = (new Connection())->connect();


$post = new Post($pdo);
$get = new Get($pdo);
$patch = new Patch($pdo);
$delete = new Delete($pdo);
$auth = new Authentication($pdo);



if(isset($_REQUEST['request'])){
    $request = explode("/", $_REQUEST['request']);
}else{
    echo "URL does not exist please try again";
    echo json_encode(["message" => "Invalid URL. Please provide a valid endpoint."]);
    exit();
}


switch($_SERVER['REQUEST_METHOD']){


    case "GET":

        switch($request[0]){ 

            case "customer": //for customers_table db
            if ($auth->isAuthorized()) {

            if (count($request) > 1){
                    echo json_encode($get->GetCustomer_tbl($request[1]));
                }else{
                echo json_encode($get->GetCustomer_tbl($request[1]));
                     }      

            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
            http_response_code(403);
            }
            break;

            case "account": //for accounts_tbl db
            if ($auth->isAuthorized()) {

            if (count($request) > 1){
                    echo json_encode($get->GetAccounts_tbl($request[1]));
                }else{
                    echo json_encode($get->GetAccounts_tbl());
                    }     

            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
            http_response_code(403);
            }
                    break;

            case "history": // For retrieving logs
            if ($auth->isAuthorized()) {

                echo json_encode($get->getLogs($request[1] ?? date("Y-m-d")));    
        
            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
            http_response_code(403);
                }
                    break;

            case "rental": // For rentals_tbl database

                if ($auth->isAuthorized()) {

                if (count($request) > 1){
                    echo json_encode($get->GetRentals_tbl($request[1]));
                }else{
                    echo json_encode($get->GetRentals_tbl());
                    }

                } else {
                    echo json_encode([
                        "status" => "error",
                        "code" => 403 ]);
                http_response_code(403);
                }  
                break;     


            case "cars": // For cars_tbl database
                if (count($request) > 1){
                    echo json_encode($get->GetCars_tbl($request[1]));
                    echo json_encode([
                        "WANT TO RENT A CAR?" => "Please provide the necessary details in the request body.",
                        "Endpoint Info" => "enter ( rental ) "
                    ]);
                }else{
                    echo json_encode($get->GetCars_tbl());
                    }
                      
                break;
            

            default:
                http_response_code(404);
                    echo json_encode([
             "status" => "error",
             "code" => 404,
             "message" => "endpoint is not valid."
             ]);
            
        }//get

        break;//case break
###################
case "POST":
    $body = json_decode(file_get_contents("php://input"), true);

        switch($request[0]){

            case "customer": // insert data records from Customers_table 
                echo json_encode($post->PostCustomers_table($body));
            break;

            case "rental": // insert data records from rentals_table 
                echo json_encode($post->PostRentals($body,$request[1]));
            break;

            case "cars": // // insert data records from cars_tbl
             if ($auth->isAuthorized()) {

                echo json_encode($post->PostCars_tbl($body));
            
            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
            http_response_code(403);
                }    
            break;    

            ############## AUTH ##############   

            case "add": // adding user accounts
                echo json_encode($auth->addAccount($body));
            break;

            case "login": // LOG IN (METHOD)
                echo json_encode($auth->login($body));
            break;
            
            default:
                http_response_code(404);
                echo json_encode([
                    "status" => "error",
                    "code" => 404,
                    "message" => "The requested endpoint could not be found.",
                    "details" => "Please check the URL or refer to the API documentation for valid endpoints."
                ]);
        }//post

    break;

// ####################              
    case "PATCH":

        $body = json_decode(file_get_contents("php://input"));
        switch($request[0]){ 
    
            case "customer":
              echo json_encode($patch->PatchCustomers_table($body,$request[1]));
              http_response_code(200);
              echo json_encode($get->GetCustomer_tbl($request[1]));
            break;

            case "cars":

            if ($auth->isAuthorized()) {

              echo json_encode($patch->PatchCars_tbl($body,$request[1]));
              http_response_code(200);
              echo json_encode($get->GetCars_tbl($request[1]));

            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
                http_response_code(403);
            }  
            break;
    
            default:
                http_response_code(404);
                    echo json_encode([
             "status" => "error",
             "code" => 404,
             "message" => "The requested endpoint could not be found.",
             "details" => "Please check the URL or refer to the API documentation for valid endpoints."
             ]);
            
        }//patch
        break;//case break 
####################              
    case "DELETE":

        switch($request[0]){ 
    
            case "customer"://archive data record from (customer_table).
                echo json_encode($patch->archiveCustomers_tbl($request[1]));       
            break;
            
            case "DEScustomer": //Permanet Delete from (customer_table) (DES) -> DESTROY
    
            if ($auth->isAuthorized()) {
                try{
                echo json_encode($delete->deletecustomer($request[1])); 
                }catch(\PDOException $e){
                        $errsmg = $e->getMessage();
                        $code = 400;
                    return array("errmsg"=>$errsmg, "code"=>$code);}

            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
                http_response_code(403);
            }
            break;

            case "DEScars": //Permanet Delete USER DATA_record from ("cars_tbl")
    
            if ($auth->isAuthorized()) {
                try{
                echo json_encode($delete->deletecars($request[1])); 
                }catch(\PDOException $e){
                        $errsmg = $e->getMessage();
                        $code = 400;
                     return array("errmsg"=>$errsmg, "code"=>$code);}
    
            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
                http_response_code(403);
            }
            break;

            case "DESrental": //Permanet Delete USER DATA_record from ("rentals_tbl")
    
            if ($auth->isAuthorized()) {

                try{
                echo json_encode($delete->deleteRentals($request[1])); 
                }catch(\PDOException $e){
                        $errsmg = $e->getMessage();
                        $code = 400;
                     return array("errmsg"=>$errsmg, "code"=>$code);}
    
            } else {
                echo json_encode([
                    "status" => "error",
                    "code" => 403 ]);
                http_response_code(403);
            }
            break;

            
            
            default:
                http_response_code(404);
                    echo json_encode([
             "status" => "error",
             "code" => 404,
             "message" => "The requested endpoint could not be found.",
             "details" => "Please check the URL or refer to the API documentation for valid endpoints."
             ]);
            
        }//del
        break;//case break 
####################

    default:
    http_response_code(404);
    echo json_encode(["message" => "Endpoint not found please try again."]);
    exit();

}//switch

?>