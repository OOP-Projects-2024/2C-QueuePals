<?php

include_once"Common.php";
//inheretance
class Get extends CommonMeThods{
    protected $pdo;
    public function __construct(\PDO $pdo){
    $this->pdo =$pdo; //initialize
                                          }
public function getlogs($data = "2024-12-18") {
    try {
        $filename = $data . ".log"; 
        $filePath = "./history-logs/$filename";

    if (!file_exists($filePath)) {
            //No Records
            throw new Exception("Log file for the given date does not exist.");
    }

        $file = file_get_contents($filePath);
        
        $logs = explode(PHP_EOL, $file);

        return $this->sendResponse(array("logs" => $logs), "Here's the log history for today's data.", "History logs retrieved successfully", 200);
    } catch (Exception $e) {
        return $this->sendResponse(null, "Failed to retrieve logs.", $e->getMessage(), 500);
    }
}//getlogs

####################  RETRIEVE RECORDS  #########################

public function GetAccounts_tbl($id = null){
   
    $sqlString = "SELECT id, username, token FROM accounts_table";


 if($id!= null){
$sqlString .= " WHERE id=" . $id; 
 }

  $data = array();
  $errmsg = "";
  $code = 0;


  try{ 
    if($result = $this->pdo->query($sqlString)->fetchAll()){

        foreach($result as $record){
        array_push($data, $record);
                                   }

   $result = null;
   $code = 200;
   
   return array("status" => "success", "code" => $code, "message" => "The requested records have been successfully retrieved.", "data" => $data, "details" => "Your request was processed without any issues.");
                                                          }
    
    else{ // if there is no record
        $errmsg = "No records were found matching your search criteria.";
        $code = 404;
        }

     }

   catch(\PDOException $e){  
$errmsg = $e ->GetMessage();
$code = 403;
return array("status" => "error", "code" => $code, "message" => "An error occurred while processing your request. Please try again later.", "details" => "Our team has been notified of the issue. If the problem persists, please contact support .");
  
                         }
return array("code"=>$code, "errmsg"=>$errmsg);
} //GetAccounts_table



public function GetCustomer_tbl($id = null){
        
    $condition = "isdeleted = 0";
    if($id != null){
    $condition .= " AND id = $id";
    }
    $result = $this->getDataByTable("customers_table", $condition, $this->pdo);

    if($result['code'] == 200){
    return $this->sendResponse($result['data'], "db records have been retrieved", "success", $result['code']);
    }

    return $this->sendResponse(null, $result['errmsg'], "failed", $result['code']);
    
}

public function GetCars_tbl($id = null){
        
 
    $sqlString = "SELECT * FROM cars_tbl";


 if($id!= null){
$sqlString .= " WHERE id=" . $id ; 
 }

  $data = array();
  $errmsg = "";
  $code = 0;

 
  try{ 
    if($result = $this->pdo->query($sqlString)->fetchAll()){ //fetch record from db

        foreach($result as $record){
        array_push($data, $record);
                                   }

   $result = null;
   $code = 200;

   return array("status" => "success", "code" => $code, "message" => "The requested records have been successfully retrieved.", "data" => $data, "details" => "Your request was processed without any issues.");
                                                          }
    
    else{
        $errmsg = "No records were found matching your search criteria.";
        $code = 404;
        }

     }

   catch(\PDOException $e){ 
$errmsg = $e ->GetMessage();
$code = 403;
return array("status" => "error", "code" => $code, "message" => "An error occurred while processing your request. Please try again later.", "details" => "Our team has been notified of the issue. If the problem persists, please contact support .");
  
                         }
return array("code"=>$code, "errmsg"=>$errmsg);
    
}

public function GetRentals_tbl($id = null){
        
    
    $sqlString = "SELECT * FROM rentals_tbl";


 if($id!= null){
$sqlString .= " WHERE id=" . $id ; 
 }

  $data = array();
  $errmsg = "";
  $code = 0;

  
  try{ 
    if($result = $this->pdo->query($sqlString)->fetchAll()){ 

        foreach($result as $record){
        array_push($data, $record);
                                   }

   $result = null;
   $code = 200;
  
   return array("status" => "success", "code" => $code, "message" => "The requested records have been successfully retrieved.", "data" => $data, "details" => "Your request was processed without any issues.");
                                                          }
    
    else{ 
        $errmsg = "No records were found matching your search criteria.";
        $code = 404;
        }

     }

   catch(\PDOException $e){ 
$errmsg = $e ->GetMessage();
$code = 403;
return array("status" => "error", "code" => $code, "message" => "An error occurred while processing your request. Please try again later.", "details" => "Our team has been notified of the issue. If the problem persists, please contact support .");
  
                         }
return array("code"=>$code, "errmsg"=>$errmsg);
    
}

}
?>