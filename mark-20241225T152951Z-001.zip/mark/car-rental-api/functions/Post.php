<?php
include_once "Common.php";

class Post extends CommonMeThods{
//jiro dichos
    protected $pdo;
    public function __construct(\PDO $pdo){ //pdo object
    $this->pdo =$pdo; //initialize
                                          }

    public function PostCustomers_table($body){
        $result = $this->postData("customers_table", $body, $this->pdo);
        
           ###### Getting-User-Name ######
        $authUser = $this->getHeaderValue("X-Auth-User");

        if($result['code'] == 200){

            ###### logging data's #####
        $this->logger($authUser, "POST", "Created a new record ");
        return $this->sendResponse($result['data'], "success", "Successfully created a new record.", $result['code']);
       }
            ###### logging data's #####
        $this->logger($authUser, "POST", $result['errmsg']);
       return $this->sendResponse(null, "(ERROR!) An error occurred, Failed to create record", $result['errmsg'], $result['code']);
         
    }

    public function PostCars_tbl($body){
        $result = $this->postData("cars_tbl", $body, $this->pdo);
        
           ###### Getting-User-Name ######
        $authUser = $this->getHeaderValue("X-Auth-User"); 

        if($result['code'] == 200){

            ###### logging data's #####
         $this->logger($authUser, "POST", "Created a new record");
         return $this->sendResponse($result['data'], "success", "Successfully created a new record.", $result['code']);
       }
            ###### logging data's #####
        $this->logger($authUser, "POST", $result['errmsg']);
       return $this->sendResponse(null, "(failed) An error occurred while creating the record ", $result['errmsg'], $result['code']);
         
    }

    public function PostRentals($body, $id = null) {
        
        $result = $this->postData("rentals_tbl", $body, $this->pdo);
    
        ###### Getting-User-Name ######
        $authUser = $this->getHeaderValue("X-Auth-User"); 
    
        if ($result['code'] == 200) {
            ###### Logging data ######
            $this->logger($authUser, "POST", "Created a new record");
            return $this->sendResponse($result['data'], "success", "Successfully created a new record.", $result['code']);
        }
    
        ###### Logging data ######
        $this->logger($authUser, "POST", $result['errmsg']);
        return $this->sendResponse(null, "(failed) An error occurred while creating the record", $result['errmsg'], $result['code']);
    }
    
}//post
?>