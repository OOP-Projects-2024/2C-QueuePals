<?php
class CommonMeThods{

###### Getting-User-Name-Header ######                                
public function getHeaderValue($headerName) {
$headers = getallheaders(); // Fetch all headers
return isset($headers[$headerName]) ? $headers[$headerName] : null;
} 

######## LOGGER METHOD #########
protected function logger($user, $method, $action){//post , patch , delete
    $filename = date("Y-m-d") . ".log";
    $datetime = date("Y-m-d H:i:s");
    $logMessage = "$datetime,$method,$user,$action" . PHP_EOL;
    file_put_contents("./history-logs/$filename", $logMessage, FILE_APPEND | LOCK_EX);
  
    
}
########pulling records#########
protected function getDataByTable($tableName, $condition, \PDO $pdo){

        $data = array();
        $errmsg = "";
        $code = 0;


        $sqlString = "SELECT * FROM $tableName WHERE $condition";

        try{  
          if($result = $pdo->query($sqlString)->fetchAll()){ 
            // Check if records exist
              foreach($result as $record){
              array_push($data, $record);
                                         }
         $result = null;
         $code = 200;
         $message = "The requested operation have been completed from the database('$tableName'.).";
         return array("code"=>$code , "data"=>$data, "message"=>$message);
         
                                                                }
          
          else{ 
              $errmsg = "No records matching the specified data.";
              $code = 404;
              }
  
           }
  
         catch(\PDOException $e){ 
      $errmsg = $e ->GetMessage();
      $code = 403;
        
                               }
      return array("code"=>$code, "errmsg"=>$errmsg);
}

//sending response & payload
protected function sendResponse($data, $message, $remarks, $statusCode){
    $status = array(
      "remark" => $remarks,
      "message" => $message
  );
  
  http_response_code($statusCode);
  
  return array(
      "Admin" => "Mark Torres",
      "date_generated" => date_create(),
      "status" => $status,
      "payload" => $data
    
  );
  }
  

########inserting records#########
private function generateInsertString($tablename, $body){
  $keys = array_keys($body);
  $fields = implode(",", $keys);
  $parameter_array = [];
  for($i = 0; $i < count($keys); $i++){
      $parameter_array[$i] = "?";
  }
  $parameters = implode(',', $parameter_array);
  $sql = "INSERT INTO $tablename($fields) VALUES ($parameters)"; 
  return $sql;
}

public function postData($tableName, $body, \PDO $pdo){
  $values = [];
  $errmsg = "";
  $code = 0;


  foreach($body as $value){
      array_push($values, $value);
  }
  
  try{
      $sqlString = $this->generateInsertString($tableName, $body);
      $sql = $pdo->prepare($sqlString);
      $sql->execute($values);

      $code = 200;
      $data = null;

      return array("data"=>$data, "code"=>$code);
  }
  catch(\PDOException $e){
      $errmsg = $e->getMessage();
      $code = 400;
  }

  
  return array("errmsg"=>$errmsg, "code"=>$code);

}
################################
}
?>