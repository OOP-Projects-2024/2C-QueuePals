<?php

    include_once"Common.php";

    class Patch extends CommonMeThods{

    protected $pdo;
    public function __construct(\PDO $pdo){
    $this->pdo =$pdo; //initialize
                                      }
    public function PatchCustomers_table($body, $id){ 

                      ###### Getting-User-Name ######
    $authUser = $this->getHeaderValue("X-Auth-User");

     $values = []; 
     $errsmg = "";
     $code = 0;

    foreach($body as $value){
    array_push($values, $value);
    }
    array_push($values, $id); 

    try{
         $sqlString = "UPDATE customers_table SET name=?, email=?, phone =? WHERE id = ?";
         
    $sql = $this->pdo->prepare($sqlString); 
    $sql->execute($values);

    $code = 200;
    $data = null;
    $message = " record is updated.";
   

    
            ###### logging data's #####
    $this->logger($authUser, "PATCH", "data record is PATCH");

    return array("data"=>$data,"message"=>$message, "code"=>$code);

    }catch(\PDOException $e){
        $errsmg = $e->getMessage();
        $code = 400;

    }
                ###### logging data's #####
    $this->logger($authUser, "PATCH", $errsmg);
    return array("errmsg"=>$errsmg, "code"=>$code);

    }

    public function PatchCars_tbl($body, $id){ 

        ###### Getting-User-Name ######
    $authUser = $this->getHeaderValue("X-Auth-User"); 

    $values = []; 
    $errsmg = "";
    $code = 0;

    foreach($body as $value){
    array_push($values, $value);
    }
    array_push($values, $id); 

    try{
    $sqlString = "UPDATE cars_tbl SET model=?, daily_rental_rate=?, car_condition=?, availability=? WHERE id = ?";

    $sql = $this->pdo->prepare($sqlString); 
    $sql->execute($values);

    $code = 200;
    $data = null;
    $message = " record updated.";



    ###### logging data's #####
    $this->logger($authUser, "PATCH", "data record is PATCH ");

    return array("data"=>$data,"message"=>$message, "code"=>$code);

    }catch(\PDOException $e){
    $errsmg = $e->getMessage();
    $code = 400;

    }
    ###### logging data's #####
    $this->logger($authUser, "PATCH", $errsmg);
    return array("errmsg"=>$errsmg, "code"=>$code);

    }   

    ############ ARCHIVE DATA RECORDS ############
    public function archiveCustomers_tbl($id){
                  ###### Getting-User-Name ######
    $authUser = $this->getHeaderValue("X-Auth-User"); 
        $code = 0;

       try{
                      // UPDATING DATA RECORD FROM DB
            $sqlString = "UPDATE customers_table SET isdeleted=1 WHERE id = ?";
            
       $sql = $this->pdo->prepare($sqlString);
       $sql->execute([$id]);
   

       $code = 200;
       $data = null;
      $message = "The record has been successfully archived.";
      $recovery_info = "contact admin to recover account data record.";
                    ###### logging data's #####
        $this->logger($authUser, "DELETE", "data record is ARCHIVE");
   
        return array("data"=>$data, "code"=>$code, "message"=>$message, "recovery_info"=>$recovery_info);
   
       }catch(\PDOException $e){
           $errsmg = $e->getMessage();
           $code = 400;
       }
                    ###### logging data's #####
       $this->logger($authUser, "DELETE", $errsmg);
   
       return array("errmsg"=>$errsmg, "code"=>$code);
   
    }

}//patch
?>