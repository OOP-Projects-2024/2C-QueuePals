-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2024 at 05:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_rental_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts_table`
--

CREATE TABLE `accounts_table` (
  `id` int(255) NOT NULL,
  `username` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts_table`
--

INSERT INTO `accounts_table` (`id`, `username`, `password`, `token`) VALUES
(1, 'princess tiong', 'gandako123', 'token null'),
(2, 'jiro', '$2y$10$N2NlNjJmMThlM2M2OTZjNeMej6kG2oVCLVUaz50Qp32jcvlGIxMTa', 'OTdkOTg1YjViYjI3YzNmMDFkN2Q1YTVjMjQ1NzQ3NWEwNWYwNWVlYjgzNTM4NTA1MjJjMjliMTgwNmNiNTY2NQ==');

-- --------------------------------------------------------

--
-- Table structure for table `cars_tbl`
--

CREATE TABLE `cars_tbl` (
  `id` int(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `daily_rental_rate` decimal(65,0) NOT NULL,
  `car_condition` varchar(255) DEFAULT NULL,
  `availability` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cars_tbl`
--

INSERT INTO `cars_tbl` (`id`, `model`, `daily_rental_rate`, `car_condition`, `availability`) VALUES
(1, 'Toyota Corolla 2020', 2500, 'good as new', 10),
(2, 'honda civic 2024', 3000, 'back seater light blinking,left seater head rest ripped', 1),
(3, 'royce II 2024', 3000, 'good as new', 2),
(4, 'roll royce II 2024', 3000, 'good as new', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers_table`
--

CREATE TABLE `customers_table` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` bigint(255) DEFAULT NULL,
  `isdeleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers_table`
--

INSERT INTO `customers_table` (`id`, `name`, `email`, `phone`, `isdeleted`) VALUES
(1, 'mark torres', 'torres@gmail.com', 9995512692, 0),
(2, 'Luise Florenz J.', 'Florenz@gmail.com', 9965328162, 0),
(3, 'jiro p. dichos', 'dichos@gmail.com', 9969664162, 0);

-- --------------------------------------------------------

--
-- Table structure for table `rentals_tbl`
--

CREATE TABLE `rentals_tbl` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `car_id` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `start_date` datetime NOT NULL DEFAULT current_timestamp(),
  `end_date` datetime NOT NULL,
  `total_price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals_tbl`
--

INSERT INTO `rentals_tbl` (`id`, `customer_id`, `car_id`, `name`, `start_date`, `end_date`, `total_price`) VALUES
(1, 1, '1', 'jiro dichos', '2024-12-13 12:39:29', '2024-12-14 08:00:00', 2500),
(2, 2, '2', 'Luise Florenz J.', '2024-12-18 01:23:36', '2024-12-20 08:00:00', 6000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts_table`
--
ALTER TABLE `accounts_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars_tbl`
--
ALTER TABLE `cars_tbl`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `model` (`model`);

--
-- Indexes for table `customers_table`
--
ALTER TABLE `customers_table`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `rentals_tbl`
--
ALTER TABLE `rentals_tbl`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts_table`
--
ALTER TABLE `accounts_table`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cars_tbl`
--
ALTER TABLE `cars_tbl`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers_table`
--
ALTER TABLE `customers_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rentals_tbl`
--
ALTER TABLE `rentals_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
